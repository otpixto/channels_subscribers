<?php

Route::get('add/{a}/{b}', 'Otpixto\ChannelsSubscribers\ChannelsSubscribersController@add');
Route::get('subtract/{a}/{b}', 'Otpixto\ChannelsSubscribers\ChannelsSubscribersController@subtract');
<?php
return [

    'url' => env('GITHUB_API_URL'),

    'user-agent' => $_SERVER['HTTP_USER_AGENT']

];
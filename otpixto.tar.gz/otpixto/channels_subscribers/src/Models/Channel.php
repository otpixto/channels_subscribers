<?php

namespace Otpixto\ChannelsSubscribers\Models;

use Illuminate\Database\Eloquent\Model;

class Channel extends Model
{
    public $timestamps = false;
}

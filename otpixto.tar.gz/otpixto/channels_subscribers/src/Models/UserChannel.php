<?php

namespace Otpixto\ChannelsSubscribers\Models;

use Illuminate\Database\Eloquent\Model;

class UserChannel extends Model
{
    //
}
